# Damilola Adeyemi — Portfolio (White Hut Org™)

A static, single-file portfolio. No build step. Data-driven: all projects live in one `PROJECTS` array inside `index.html`.

## Deploy: GitHub → Vercel
1. Create a GitHub account and a new repository, e.g. `portfolio`.
2. Upload every file in this folder (GitHub website: Add file → Upload files).
3. Go to vercel.com, sign in with GitHub, choose Add New → Project, pick the repository, and press Deploy. No settings needed.
4. Vercel gives you a public URL. The site is not "live" until this works.

## After deploying
- Add the real URL to `robots.txt` and, if you like, a `<link rel="canonical">` in `index.html`.
- Set your custom domain in Vercel → Settings → Domains.

## Add a project
Open `index.html`, find `PROJECTS`, copy an existing object, change the fields. Rules:
- `status`: Completed, Live, In Progress, Prototype, Experiment, Case Study, Architecture, Planned or Service Capability.
- Set `liveUrl` and `githubUrl` only to real URLs; use `null` otherwise (the button is hidden).
- Add a `caseStudy` object to get a full case-study page. Unknown fields show "Documentation in progress".

## Contact details and analytics
- Edit the `CONTACT` object near the top of the script (email, WhatsApp, LinkedIn, GitHub).
- Analytics: paste your snippet at the marked comment in `<head>` once you have a real ID. Never commit secrets.
