# Portfolio status

## Live (public site verified; my contribution to be documented)
- SRLHD Institutional Website Ecosystem, SRLHD Programmes, SRLHD — The Sanctuary

## In progress
- SRLHD Marketing & Growth Digital System
- Fraud Detection Framework (PaySim and European Credit Card datasets as components)
- AI-Powered Business Automation, Business Operations Dashboard, Cybersecurity Portfolio, this portfolio

## Prototype
- Live Trading Website — Concept (simulated data)

## Planned
- UI/UX Projects

## Evidence needed
- Exact personal role and dates for each SRLHD project
- Screenshots you took yourself of your own work
- GitHub repository for the fraud detection project, with README, metrics and limitations
- LinkedIn and GitHub profile links
- Live URL after Vercel deployment

## Case studies needed
- SRLHD growth system, fraud detection (results), this portfolio (performance/SEO checks)
